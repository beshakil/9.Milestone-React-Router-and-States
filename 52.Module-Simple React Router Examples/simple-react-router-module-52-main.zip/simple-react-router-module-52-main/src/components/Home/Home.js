import React from 'react';
import Posts from '../Posts/Posts';

const Home = () => {
    return (
        <div>
            <h2>This is Home</h2>
            <Posts></Posts>
        </div>
    );
};

export default Home;