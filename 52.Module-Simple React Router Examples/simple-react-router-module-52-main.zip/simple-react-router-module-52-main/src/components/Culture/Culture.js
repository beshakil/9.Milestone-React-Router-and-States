import React from 'react';

const Culture = () => {
    return (
        <div>
            <h2>Our culture is cool</h2>
            <p>We have free water and free floor for seating</p>
        </div>
    );
};

export default Culture;