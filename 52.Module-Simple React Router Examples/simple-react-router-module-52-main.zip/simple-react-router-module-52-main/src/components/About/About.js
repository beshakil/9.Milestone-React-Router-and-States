import React from 'react';

const About = () => {
    return (
        <div>
            <h2>This is about us page</h2>
            <p>You can know all about us if you bring some biryani. </p>
        </div>
    );
};

export default About;