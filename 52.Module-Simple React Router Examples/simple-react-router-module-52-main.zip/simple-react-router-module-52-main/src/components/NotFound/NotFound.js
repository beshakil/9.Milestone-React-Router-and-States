import React from 'react';

const NotFound = () => {
    return (
        <div>
            <h3>Page not found</h3>
            <p>Don't ask me about this page.</p>
        </div>
    );
};

export default NotFound;